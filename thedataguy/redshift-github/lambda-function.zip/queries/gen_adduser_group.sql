SELECT 'ALTER GROUP ' 
       ||groname 
       ||' ADD USER ' 
       ||usename 
       ||';' AS ddl 
FROM   ADMIN.v_get_users_in_group; 