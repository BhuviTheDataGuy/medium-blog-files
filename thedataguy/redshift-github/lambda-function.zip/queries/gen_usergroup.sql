SELECT 'CREATE GROUP ' + Quote_ident(groname) + ';' AS ddl 
FROM   pg_catalog.pg_group 
ORDER  BY groname; 