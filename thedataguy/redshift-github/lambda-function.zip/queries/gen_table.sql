SELECT ddl 
FROM   ((SELECT * 
         FROM   ADMIN.v_generate_tbl_ddl 
         WHERE  ddl NOT LIKE 'ALTER TABLE %' 
         ORDER  BY tablename) 
        UNION ALL 
        (SELECT * 
         FROM   ADMIN.v_generate_tbl_ddl 
         WHERE  ddl LIKE 'ALTER TABLE %' 
         ORDER  BY tablename)) 