SELECT ddl 
FROM   ADMIN.v_generate_schema_ddl; 