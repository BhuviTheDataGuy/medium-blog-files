SELECT ddl 
FROM   ADMIN.v_generate_user_object_permissions 
WHERE schemaname NOT IN ( 'information_schema', 'pg_catalog' ) 
       AND usename <> 'rdsdb'; 