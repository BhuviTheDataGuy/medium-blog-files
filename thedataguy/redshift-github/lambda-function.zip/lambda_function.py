import os
from github import Github
import psycopg2
from datetime import datetime

# Env variables
GITHUB_ACCESS_TOKEN = os.environ['GITHUB_ACCESS_TOKEN']
GITHUB_REPO         = os.environ['GITHUB_REPO']
GITHUB_PREFIX       = os.environ['GITHUB_PREFIX']
REDSHIFT_DATABASE = os.environ['REDSHIFT_DATABASE']
REDSHIFT_USER     = os.environ['REDSHIFT_USER']
REDSHIFT_PASSWD   = os.environ['REDSHIFT_PASSWD']
REDSHIFT_PORT     = os.environ['REDSHIFT_PORT']
REDSHIFT_ENDPOINT = os.environ['REDSHIFT_ENDPOINT']

#Github access token or credentials
# g = Github("username", "password") -- Insead of token, you can use username and password
g = Github(GITHUB_ACCESS_TOKEN)



# Declare other variables
timestampStr = datetime.now().strftime("%Y%m%d-%H%M%S")
gitcomment = 'updated at ' + timestampStr
query_list = ['gen_schema', 'gen_table', 'gen_usergroup', 'gen_adduser_group', 'gen_object_grants']
path = '/tmp/rsgit/'
os.system('mkdir -p ' + path)      

# RedShift Connection 
def get_pg_con(
    user=REDSHIFT_USER,
    password=REDSHIFT_PASSWD,
    host=REDSHIFT_ENDPOINT,
    dbname=REDSHIFT_DATABASE,
    port=REDSHIFT_PORT,
    ):
    return psycopg2.connect(dbname=dbname, 
      host=host, 
      user=user,
      password=password,
      port=port)

# Main function      
def lambda_handler(handler, context):
    # Get all the exsiting files
    repo = g.get_user().get_repo(GITHUB_REPO)
    all_files = []
    contents = repo.get_contents("")
    while contents:
        file_content = contents.pop(0)
        if file_content.type == "dir":
            contents.extend(repo.get_contents(file_content.path))
        else:
            file = file_content
            all_files.append(str(file).replace('ContentFile(path="','').replace('")',''))
    print(all_files)
    os.system('ls -al ')
    conn = get_pg_con()
    cur = conn.cursor()
    
    for query in query_list:

        # read SQL query
        with open ('queries/' + str(query) + '.sql') as file:
            sqlquery = file.read()
        cur.execute(sqlquery)
        result = cur.fetchall()
        # Process all the rows one by one
        rows = []
        for row in result:
            rows.append(''.join(row).encode().decode('utf-8'))
        
        # Write the results to a file
        with open(path + query + '.sql', 'w') as file:
            for item in rows:
                file.write("%s\n" % item)
        
        # Read the result file
        with open(path + query + '.sql', 'r') as file:
            content = file.read()
        
        # Upload to github
        git_prefix = GITHUB_PREFIX
        git_file = git_prefix + query + '.sql'
        if git_file in all_files:
            contents = repo.get_contents(git_file)
            repo.update_file(contents.path, gitcomment, content, contents.sha, branch="master")
            print(git_file + ' UPDATED')
        else:
            repo.create_file(git_file, gitcomment, content, branch="master")
            print(git_file + ' CREATED')